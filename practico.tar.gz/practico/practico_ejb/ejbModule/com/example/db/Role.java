package com.example.db;

public enum Role {
	PLAYER, ADMIN;
}
