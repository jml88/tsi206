package com.example.service;

import javax.ejb.Local;

@Local
public interface EnviarMensajeI {
	
	public void publicaMensaje();
}
