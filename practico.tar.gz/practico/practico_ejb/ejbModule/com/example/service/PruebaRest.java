package com.example.service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Path;


@Stateless
@LocalBean
@Path("/customers")
public class PruebaRest {

}
